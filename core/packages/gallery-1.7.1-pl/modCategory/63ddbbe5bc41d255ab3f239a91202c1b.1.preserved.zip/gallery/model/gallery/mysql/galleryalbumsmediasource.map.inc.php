<?php
/**
 * @package gallery
 */
$xpdo_meta_map['GalleryAlbumsMediaSource']= array (
  'package' => 'gallery',
  'version' => NULL,
  'extends' => 'modMediaSource',
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
