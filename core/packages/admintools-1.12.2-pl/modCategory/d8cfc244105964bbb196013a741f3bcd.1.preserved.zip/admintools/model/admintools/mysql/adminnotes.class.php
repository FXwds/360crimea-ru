<?php
require_once (dirname(dirname(__FILE__)) . '/adminnotes.class.php');
class adminNotes_mysql extends adminNotes {}