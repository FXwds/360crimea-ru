<?php
require_once dirname(__DIR__) . '/get_versions.class.php';

class VersionXResourcesGetVersionsProcessor extends VersionXGetVersionsProcessor {
    public $classKey = 'vxResource';
}
return 'VersionXResourcesGetVersionsProcessor';
