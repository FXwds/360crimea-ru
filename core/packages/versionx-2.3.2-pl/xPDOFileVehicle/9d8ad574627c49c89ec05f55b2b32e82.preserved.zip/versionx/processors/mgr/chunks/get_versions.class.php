<?php
require_once dirname(__DIR__) . '/get_versions.class.php';

class VersionXChunksGetVersionsProcessor extends VersionXGetVersionsProcessor {
    public $classKey = 'vxChunk';
}
return 'VersionXChunksGetVersionsProcessor';
