<?php
/**
 * @package collections
 */
require_once(strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/collectiontemplatecolumn.class.php');

class CollectionTemplateColumn_mysql extends CollectionTemplateColumn
{
}
