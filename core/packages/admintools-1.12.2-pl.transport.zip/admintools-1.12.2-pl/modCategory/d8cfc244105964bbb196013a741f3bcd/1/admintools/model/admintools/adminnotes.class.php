<?php
/**
 * @package admintools
 */
class adminNotes extends xPDOSimpleObject {}